export default {
  plugins: {
    autoprefixer: {},
    'postcss-preset-env': { stage: 3 },
    cssnano: { preset: 'default' }
  }
};
